const nome = document.getElementById('nome');
const cnpj = document.getElementById('cnpj');
const cpf = document.getElementById('cpf');
const endprof = document.getElementById('endprof');
const endres = document.getElementById('endres');
const espec = document.getElementById('espec');
const dataemi = document.getElementById('dataemi');
const resp = document.getElementById('resp');
const identidade = document.getElementById('identidade');
const cr = document.getElementById('cr');
const addButton = document.getElementById('addButton');
const db = firebase.database();
const gerarPdf = document.getElementById('gerarPdf');

addButton.addEventListener('click',function() {
    var data = new Date();
    var dia = data.getDate();           // 1-31
    var mes = data.getMonth()+1;          // 0-11 (zero=janeiro)
    var ano = data.getFullYear();  
    if (mes==1) {
      mes = "de Janeiro de";
    }
    if (mes==2) {
      mes = "de Fevereiro de";
      
    }
    if (mes==3) {
      mes = "de Março de";
      
    }
    if (mes==4) {
      mes = "de Abril de";
      
    }
    if (mes==5) {
      mes = "de Maio de";
      
    }
    if (mes==6) {
      mes = "de Junho de";
      
    }
    if (mes==7) {
      mes = "de Julho de";
      
    }
    if (mes==8) {
      mes = "de Agosto de";
      
    }
    if (mes==9) {
      mes = "de Setembro de";
      
    }
    if (mes==10) {
      mes = "de Outubro de";
      
    }
    if (mes==11) {
      mes = "de Novembro de";
      
    }
    if (mes==12) {
      mes = "de Dezembro de";
      
    }
    datavalue = dataemi.value;
    split = datavalue.split('-');
    datavalue2 = split[2] + "/" +split[1]+"/"+split[0];
    var doc = new jsPDF();    
    doc.setFont("italic");    
    doc.setFontType("bold");
    doc.setFontSize(18);      
    doc.text('REQUISIÇÃO DE NOTIFICAÇÃO DE RECEITA', 37, 22);   
    doc.setFontType("bold");    
    doc.setFontSize(11);          
    doc.setFont("italic");    
    doc.text('Nome do Requisitante', 17, 36);
    doc.setFont("italic");    
    doc.setFontType("bold");    
    doc.text('Endereço ', 17, 42);
    doc.setFontType("bold");    
    doc.text('CNPJ ', 17, 48);  
    doc.text('CPF ', 17, 54);    
    doc.text('CRM,CRMV,CRO ', 17, 60);    
    doc.text('Especialidade', 100, 60);        
    doc.setFontType("normal");        
    doc.text(nome.value, 65, 36);    
    doc.text(endprof.value, 65, 42);    
    doc.text(cnpj.value, 65, 48);
    doc.text(cpf.value, 65, 54);    
    doc.text(cr.value, 65, 60);   
    doc.text(espec.value, 130, 60); 
    doc.text(resp.value, 73, 80);
    doc.text(identidade.value, 25, 86);    
    
    doc.setFontSize(12);    
    doc.setFontType('bold'); 
    doc.rect(10, 27, 190, 0.3, 'F');
    doc.rect(10, 67, 190, 0.3, 'F');
    
    doc.setFont("italic");    
    doc.setFontType('bold'); 
    doc.text('AUTORIZAÇÃO EMITIDA PELA VISA N°', 17, 74);
    doc.setFontSize(11); 
    doc.setFontType('bold');     
    doc.text('Pelo presente, autorizo o(a) Sr(a)', 17, 80);
    doc.setFontSize(11);  
    doc.setFontType('bold');     
    doc.text('RG:', 17, 86);
    doc.setFontSize(11);  
    doc.setFontType('bold'); 
    doc.text('Data da emissão:', 70, 86);
    doc.setFontSize(11);  
    doc.setFontType('bold');    
    doc.text('Residente à', 17, 92);
    doc.setFontSize(11);  
    doc.setFontType('bold'); 
    doc.text('Para retirar:', 17, 98);
    doc.setFontSize(11);  
    doc.setFontType('bold'); 
    doc.text('Notificação de Receita A    talão(ões) com numeração de:', 30, 104);
    doc.setFontSize(11);  
    doc.setFontType('bold'); 
    doc.text('Notificação de Receita B    numeração concedida de:', 30, 110);
    doc.setFontSize(11);  
    doc.setFontType('bold');
    doc.text('Notificação de Receita Especial:', 30, 116);
    doc.setFontSize(11);  
    doc.setFontType('bold');
    doc.text('Retinóides      com numeração de:', 90, 116);
    doc.setFontSize(11);  
    doc.setFontType('bold');
    doc.text('Talidomida      com numeração de:', 90, 122);
    doc.setFontSize(11);  
    doc.setFontType('bold');
    doc.text('_________________________', 120, 135);
    doc.text('Assinatura e carimbo com CR', 120, 140);
    doc.text('_________________________', 120, 145);
    doc.text('Assinatura e carimbo com CR', 120, 150);
    
    doc.setFontSize(11);  
    doc.setFontType('bold');
    doc.text('_______________________', 100, 74);
    doc.setFontSize(18);     
    doc.setFont("italic");    
    doc.setFontType("bold"); 
    doc.text('REQUISIÇÃO DE NOTIFICAÇÃO DE RECEITA', 37, 165);   
    doc.setFontType("bold");    
    doc.setFontSize(11);          
    doc.setFont("italic");    
    doc.text('Nome do Requisitante', 17, 179);
    doc.setFont("italic");    
    doc.setFontType("bold");    
    doc.text('Endereço ', 17, 185);
    doc.setFontType("bold");    
    doc.text('CNPJ ', 17, 191);  
    doc.text('CPF ', 17, 197);    
    doc.text('CRM,CRMV,CRO ', 17, 203);    
    doc.text('Especialidade', 100, 203);        
    doc.setFontType("normal"); 
    doc.text("Rio Grande, "+dia+" "+mes+" "+ano, 17, 135);     
    doc.text("Rio Grande, "+dia+" "+mes+" "+ano, 17, 275);        
    
    doc.text(nome.value, 65, 179);    
    doc.text(endprof.value, 65, 185);    
    doc.text(cnpj.value, 65, 191);
    doc.text(cpf.value, 65, 197);    
    doc.text(cr.value, 65, 203);   
    doc.text(espec.value, 130, 203); 
    doc.text(resp.value, 73, 224);       
    doc.text(identidade.value, 25, 231);
    if (datavalue2 != "undefined/undefined/"){
        doc.text(datavalue2, 100, 231);
        doc.text(datavalue2, 100, 86);        
    }
    doc.setFontSize(12);    
    doc.setFontType('bold'); 
    doc.rect(10, 170, 190, 0.3, 'F');
    doc.rect(10, 211, 190, 0.3, 'F');
    
    doc.setFont("italic");    
    doc.setFontType('bold'); 
    doc.text('AUTORIZAÇÃO EMITIDA PELA VISA N°', 17, 218);
    doc.setFontSize(11); 
    doc.setFontType('bold');     
    doc.text('Pelo presente, autorizo o(a) Sr(a)', 17, 224);
    doc.setFontSize(11);  
    doc.setFontType('bold');     
    doc.text('RG:', 17, 231);
    doc.setFontSize(11);  
    doc.setFontType('bold'); 
    doc.text('Data da emissão:', 70, 231);
    doc.setFontSize(11);  
    doc.setFontType('bold');    
    doc.text('Residente à', 17, 239);
    doc.setFontSize(11);  
    doc.setFontType('bold'); 
    doc.text('Para retirar:', 17, 245);
    doc.setFontSize(11);  
    doc.setFontType('bold'); 
    doc.text('Notificação de Receita A    talão(ões) com numeração de:', 30, 251);
    doc.setFontSize(11);  
    doc.setFontType('bold'); 
    doc.text('Notificação de Receita B    numeração concedida de:', 30, 257);
    doc.setFontSize(11);  
    doc.setFontType('bold');
    doc.text('Notificação de Receita Especial:', 30, 263);
    doc.setFontSize(11);  
    doc.setFontType('bold');
    doc.text('Retinóides      com numeração de:', 90, 263);
    doc.setFontSize(11);  
    doc.setFontType('bold');
    doc.text('Talidomida      com numeração de:', 90, 269);
    doc.setFontSize(11);  
    doc.setFontType('bold');
    doc.text('_________________________', 120, 275);
    doc.text('Assinatura e carimbo com CR', 120, 280);
    doc.text('_________________________', 120, 285);
    doc.text('Assinatura e carimbo com CR', 120, 290);
    
    doc.setFontSize(11);  
    doc.setFontType('bold');
    doc.text('_______________________', 100, 218);
    doc.save('receituario.pdf');   
    

});

